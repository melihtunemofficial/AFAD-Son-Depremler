﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlAgilityPack;
using System.Threading;
using System.Net;

namespace afad_deprem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
            Thread t = new Thread(deprem_getir);
            t.SetApartmentState(ApartmentState.STA); t.Start();
        }

        private void deprem_getir()
        {
            WebClient client = new WebClient();
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(client.OpenRead("https://deprem.afad.gov.tr/last-earthquakes.html"), Encoding.UTF8);
            HtmlNodeCollection td = doc.DocumentNode.SelectNodes("//table[@class='content-table']//tr//td");
            for (int i = 0; i < td.Count; i += 8)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i / 8].Cells[0].Value = td[i].InnerText;
                dataGridView1.Rows[i / 8].Cells[1].Value = td[i + 1].InnerText;
                dataGridView1.Rows[i / 8].Cells[2].Value = td[i + 2].InnerText;
                dataGridView1.Rows[i / 8].Cells[3].Value = td[i + 3].InnerText;
                dataGridView1.Rows[i / 8].Cells[4].Value = td[i + 4].InnerText;
                dataGridView1.Rows[i / 8].Cells[5].Value = td[i + 5].InnerText;
                dataGridView1.Rows[i / 8].Cells[6].Value = td[i + 6].InnerText;
            }
        }
    }
}
