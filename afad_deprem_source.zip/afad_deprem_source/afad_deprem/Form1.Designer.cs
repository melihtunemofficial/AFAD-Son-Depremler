﻿namespace afad_deprem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.col_tarih = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_enlem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_boylam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_derinlik = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_tip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_büyüklük = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_yer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.DimGray;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_tarih,
            this.col_enlem,
            this.col_boylam,
            this.col_derinlik,
            this.col_tip,
            this.col_büyüklük,
            this.col_yer});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(12, 44);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(613, 177);
            this.dataGridView1.TabIndex = 2;
            // 
            // col_tarih
            // 
            this.col_tarih.HeaderText = "Tarih";
            this.col_tarih.MinimumWidth = 8;
            this.col_tarih.Name = "col_tarih";
            this.col_tarih.Width = 170;
            // 
            // col_enlem
            // 
            this.col_enlem.HeaderText = "Enlem";
            this.col_enlem.MinimumWidth = 8;
            this.col_enlem.Name = "col_enlem";
            this.col_enlem.Width = 70;
            // 
            // col_boylam
            // 
            this.col_boylam.HeaderText = "Boylam";
            this.col_boylam.MinimumWidth = 8;
            this.col_boylam.Name = "col_boylam";
            this.col_boylam.Width = 70;
            // 
            // col_derinlik
            // 
            this.col_derinlik.HeaderText = "Derinlik";
            this.col_derinlik.MinimumWidth = 8;
            this.col_derinlik.Name = "col_derinlik";
            this.col_derinlik.Width = 80;
            // 
            // col_tip
            // 
            this.col_tip.HeaderText = "Tip";
            this.col_tip.MinimumWidth = 8;
            this.col_tip.Name = "col_tip";
            this.col_tip.Width = 50;
            // 
            // col_büyüklük
            // 
            this.col_büyüklük.HeaderText = "Büyüklük";
            this.col_büyüklük.MinimumWidth = 8;
            this.col_büyüklük.Name = "col_büyüklük";
            this.col_büyüklük.Width = 90;
            // 
            // col_yer
            // 
            this.col_yer.HeaderText = "Yer";
            this.col_yer.MinimumWidth = 8;
            this.col_yer.Name = "col_yer";
            this.col_yer.Width = 350;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(193, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 30);
            this.label1.TabIndex = 3;
            this.label1.Text = "AFAD Son depremler";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(636, 239);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AFAD Son Depremler";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_tarih;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_enlem;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_boylam;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_derinlik;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_tip;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_büyüklük;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_yer;
        private System.Windows.Forms.Label label1;
    }
}

